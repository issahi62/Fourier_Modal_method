=======
History
=======

0.1.2 (2020-11-01)
------------------

* Add example for hexagonal lattice

0.1.1 (2020-05-18)
------------------

* Fix license
  
0.1 (2020-05-12)
------------------

* First release on PyPI.
