==========
Convention
==========

* The vacuum permittivity, permeability, and speed of light are *1*.
* The time harmonic convention is *exp(-i omega t)*.
